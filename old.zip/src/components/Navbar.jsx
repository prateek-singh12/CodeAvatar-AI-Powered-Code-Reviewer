import React from 'react'
import { FileCode2 } from 'lucide-react';
import { Sun } from 'lucide-react';

const Navbar = () => {
    return (
        <div className="navbar flex justify-between items-center bg-purple-900 h-[50px]">
            <div className="logo p-8 flex items-center gap-2">
                <FileCode2 size={30} color='#CDC1FF' />
                <h1 className="logo-text" style={{ color: '#ffffff', fontSize: '24px' }}>CodeAvatar</h1>
            </div>
            <div className="theme-toggle cursor-pointer group">
                <Sun
                    size={30}
                    className="text-[#CDC1FF] group-hover:text-white group-hover:scale-110 transition-transform duration-200"
                />
            </div>
        </div>
    )
}

export default Navbar