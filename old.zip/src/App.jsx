import React, { useState } from 'react'
import './App.css'
import Navbar from './components/Navbar'
import Editor from '@monaco-editor/react';
import Select from 'react-select';
import { GoogleGenAI } from "@google/genai";
import Markdown from 'react-markdown'
import HashLoader from "react-spinners/HashLoader";

const ai = new GoogleGenAI({ apiKey: "AIzaSyDv3vQLN6Mj_0w93qJU-qSYFiWMnDn2w4o" });

const App = () => {
  const options = [
    { value: 'javascript', label: 'JavaScript' },
    { value: 'python', label: 'Python' },
    { value: 'java', label: 'Java' },
    { value: 'csharp', label: 'C#' },
    { value: 'cpp', label: 'C++' },
    { value: 'php', label: 'PHP' },
    { value: 'ruby', label: 'Ruby' },
    { value: 'go', label: 'Go' },
    { value: 'swift', label: 'Swift' },
    { value: 'kotlin', label: 'Kotlin' },
    { value: 'typescript', label: 'TypeScript' },
    { value: 'rust', label: 'Rust' },
    { value: 'dart', label: 'Dart' },
    { value: 'scala', label: 'Scala' },
    { value: 'perl', label: 'Perl' },
    { value: 'haskell', label: 'Haskell' },
    { value: 'elixir', label: 'Elixir' },
    { value: 'r', label: 'R' },
    { value: 'matlab', label: 'MATLAB' },
    { value: 'bash', label: 'Bash' }
  ];
  const [selectedOption, setSelectedOption] = useState(options[0]);
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState("");

  const customStyles = {
    control: (provided) => ({
      ...provided,
      backgroundColor: '#18181b',
      borderColor: '#3f3f46',
      color: '#fff',
      width: "100%"
    }),
    menu: (provided) => ({
      ...provided,
      backgroundColor: '#18181b',
      color: '#fff',
      width: "100%"
    }),
    singleValue: (provided) => ({
      ...provided,
      color: '#fff',
      width: "100%"
    }),
    option: (provided, state) => ({
      ...provided,
      backgroundColor: state.isFocused ? '#27272a' : '#18181b',
      color: '#fff',
      cursor: 'pointer',
    }),
    input: (provided) => ({
      ...provided,
      color: '#fff',
      width: "100%"
    }),
    placeholder: (provided) => ({
      ...provided,
      color: '#a1a1aa',
      width: "100%"
    }),
  };

  async function reviewCode() {
    setResponse("");
    setLoading(true);
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: `You are an expert-level software developer, skilled in writing efficient, clean, and advanced code.
I’m sharing a piece of code written in ${selectedOption.value}.
Your job is to deeply review this code and provide the following:

1️⃣ A quality rating: Better, Good, Normal, or Bad.
2️⃣ Detailed suggestions for improvement, including best practices and advanced alternatives.
3️⃣ A clear explanation of what the code does, step by step.
4️⃣ A list of any potential bugs or logical errors, if found.
5️⃣ Identification of syntax errors or runtime errors, if present.
6️⃣ Solutions and recommendations on how to fix each identified issue.

Analyze it like a senior developer reviewing a pull request.
Code: ${code}`,
    });
    console.log(response.text);
    setResponse(response.text);
    setLoading(false);
  }

  return (
    <>
      <Navbar />
      <div className="main flex justify-between" style={{ height: "calc(100vh - 50px)" }}>
        <div className="left h-full w-[50%] !ml-5">
          <div className="editor-header flex items-center justify-between w-full !gap-[4px] !px-2 bg-purple-900 h-[50px] !rounded-md !mt-5">
            <Select
              value={selectedOption}
              onChange={(e) => { setSelectedOption(e) }}
              options={options}
              styles={customStyles}
              className='w-[90%] !text-white p-[2px] !bg-zinc-900 !rounded-md ml-6'
            />
            <div className="tabs w-full flex items-center gap-[4px]">
              <button className="btnNormal bg-zinc-900 min-w-[160px] transition-all hover:bg-zinc-800">Fix Code</button>
              <button onClick={() => {
                if (code === "") {
                  alert("Please enter code first");
                } else {
                  reviewCode();
                }
              }} className="btnNormal bg-zinc-900 min-w-[160px] transition-all hover:bg-zinc-800">Review</button>
            </div>
          </div>
          <Editor
            height="85%"
            theme='vs-dark'
            language={selectedOption.value}
            value={code}
            onChange={(value) => setCode(value)}
            defaultValue='// Write your code here...'
          />
        </div>
        <div className="right overflow-scroll !p-[10px] bg-zinc-900 w-[46%] h-[94%] !rounded-md !mt-5 !mr-5">
          <div className="topTab border-b-[1px] border-[#CDCIFF] flex items-center justify-between h-[40px]">
            <p className='font-[700] text-[17px] text-[#CDC1FF]'>Response</p>
          </div>
          {loading && <div className="hash-loader"><HashLoader color="rgba(205, 193, 255, 1)" /></div>}
          <Markdown>{response}</Markdown>
        </div>
      </div>
    </>
  )
}

export default App